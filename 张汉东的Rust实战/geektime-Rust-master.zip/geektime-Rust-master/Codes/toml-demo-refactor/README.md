### Usage:

Development:

> POEM_ENV=d cargo run
> POEM_ENV=dev cargo run
> POEM_ENV=development cargo run

Staging:

> POEM_ENV=s cargo run
> POEM_ENV=stage cargo run
> POEM_ENV=staging cargo run

Production:

> POEM_ENV=p cargo run
> POEM_ENV=prod cargo run
> POEM_ENV=production cargo run